import 'es5-shim';
import "babel-polyfill";
import 'es6-promise/auto';
import 'fetch-detector';
import 'fetch-ie8';
import './mock';
// if (__DEV__) {
    //require('./mock');
// }