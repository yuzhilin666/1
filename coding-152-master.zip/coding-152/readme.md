### 语法知识点
fetch
async/await
promise
let&const
class
箭头函数
函数参数
解构
import & export
正则

### 业务知识点
sdk开发



### 实战知识点
fetchMock
webpack
babel
es6-polyfill
